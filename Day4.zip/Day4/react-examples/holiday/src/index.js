import React from 'react';
import ReactDOM from 'react-dom';
import HolidayComponent from './HolidayComponent';
import CarComponent from './CarComponent';


ReactDOM.render(<CarComponent></CarComponent>,document.getElementById('app'));
//ReactDOM.render(<HolidayComponent></HolidayComponent>,document.getElementById('app'));
import React from 'react';
import './car.css';

class CarComponent extends React.Component {

	constructor() {
		super();
		this.state = {name:'Audi Q7',price:450000.00};
	}

	render() {
		return (
			<div className='beautify'>
				<h1>Car Details</h1>
				<p>It is all about luxury cars.</p>
				<p>Name - {this.state.name}</p>
				<p>Price - {this.state.price}</p>
			</div>
		);	
	}
}

export default CarComponent;
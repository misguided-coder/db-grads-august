import React from 'react';

class HolidayComponent extends React.Component {

	render() {
		return <h1>Holiday Planner Component</h1>;	
	}
}

export default HolidayComponent;
var i = 100;
console.log(i);
console.log("I am well running!!");

for(var idx=0;idx<5;idx++){
	console.log(idx);
}

console.log(Math.random());

require('angular');
require('mysql');
var fs = require('http');
var fs = require('fs');
var calc = require('./calc.js');
console.log("Modules imported successfully!!");

calc.doSum(10,6);
calc.diff(10,6);
function sum(a,b) {
	console.log("SUM : "+(a+b));
}

function diff(a,b) {
	console.log("DIFF : "+(a-b));
}

exports.doSum = sum;
exports.diff = diff;
package com.example.solid.isp;

public interface Brakable {

	public void applyBrake();

}

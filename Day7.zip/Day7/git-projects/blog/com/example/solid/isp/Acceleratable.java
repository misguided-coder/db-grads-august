package com.example.solid.isp;

public interface Acceleratable {

	public void speedUp();

}

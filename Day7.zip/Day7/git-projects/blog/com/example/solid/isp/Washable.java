package com.example.solid.isp;

public interface Washable {

	public void wash();

}

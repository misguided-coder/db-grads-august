package com.example.solid.isp;

public interface Automobile {

	public void start();
	public void stop();
}

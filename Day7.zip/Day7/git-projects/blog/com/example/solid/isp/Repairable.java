package com.example.solid.isp;

public interface Repairable {

	public void repair();

}

package com.example.solid.ocp;

public interface Messanger {
	public abstract void sendMessage(String message);
}

package com.example.solid.srp;

public class SMSService {

	public void sendSMS(String phone) {
		// 20 LOC
		System.out.printf("Total balance alert sent to %s!!%n", phone);
	}

	public void configure(String accessPoint) {
		// TBD
	}

}

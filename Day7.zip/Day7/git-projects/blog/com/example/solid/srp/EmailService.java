package com.example.solid.srp;

public class EmailService {
	
	public void sendMail(String to) {
		//20 LOC
		System.out.printf("Total balance alert sent to %s!!%n", to);
	}

	public void downloadMail(String fromServer) {
		//TBD
	}
	
	public void configureMail(String options) {
		//TBD
	}

}

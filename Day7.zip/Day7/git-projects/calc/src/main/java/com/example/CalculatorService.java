package com.example;

public class CalculatorService{

	public int doSum(int i,int j){
		return i+j;
	}

	public int doDiff(int i,int j){
		return i-j;
	}
	
}
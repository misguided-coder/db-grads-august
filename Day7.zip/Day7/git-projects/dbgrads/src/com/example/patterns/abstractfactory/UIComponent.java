package com.example.patterns.abstractfactory;

public abstract class UIComponent {
	public abstract void draw();
}

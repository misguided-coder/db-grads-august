package com.example.patterns.factory;

public class Almirah extends Furniture {

	@Override
	public void make() {
		System.out.println("Almirah is ready!!");
	}
}

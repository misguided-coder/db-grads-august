package com.example.patterns.factory;

public abstract class Furniture {
	public abstract void make();
}

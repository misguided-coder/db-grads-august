function hello(){
	alert("Hello Mr");	
}

function hi(){
	alert("hi Mr");	
}

function doWork() {
	console.log("Div clicked!!");		
}

function doWorkOver() {
	console.log("Mouse is over Div!!");	
	var ref = document.getElementById('div0');		
	ref.innerHTML = 'I am just beautiful';
	ref.style.fontSize = '24px';
	ref.style.border = '5px solid yellow';
	ref.style.margin = 'auto';
}
